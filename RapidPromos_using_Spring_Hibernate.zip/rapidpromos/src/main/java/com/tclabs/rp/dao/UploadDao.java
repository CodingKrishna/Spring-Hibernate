package com.tclabs.rp.dao;

import com.tclabs.rp.model.CandidateEntity;

public interface UploadDao {

	void insertCandidate(CandidateEntity candidateEntity);

}
