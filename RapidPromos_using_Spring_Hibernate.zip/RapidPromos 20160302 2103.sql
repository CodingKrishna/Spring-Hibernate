-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema rapidpromos
--

CREATE DATABASE IF NOT EXISTS rapidpromos;
USE rapidpromos;

--
-- Definition of table `candidatedetails`
--

DROP TABLE IF EXISTS `candidatedetails`;
CREATE TABLE `candidatedetails` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidatedetails`
--

/*!40000 ALTER TABLE `candidatedetails` DISABLE KEYS */;
INSERT INTO `candidatedetails` (`id`,`name`,`mobile`,`email`,`location`) VALUES 
 (1,'Chalapathi','7795798957','chalapathi9845671@gmail.com','Bangalore'),
 (2,'Chalapathi1','7795798957','chalapathi9845672@gmail.com','Bangalore1'),
 (3,'Chalapathi2','7795798957','chalapathi9845673@gmail.com','Bangalore2'),
 (4,'Chalapathi3','7795798957','chalapathi9845671@gmail.com','Bangalore3'),
 (5,'Chalapathi','7795798957','chalapathi9845671@gmail.com','Bangalore'),
 (6,'Chalapathi1','7795798957','chalapathi9845672@gmail.com','Bangalore1'),
 (7,'Chalapathi2','7795798957','chalapathi9845673@gmail.com','Bangalore2'),
 (8,'Chalapathi3','7795798957','chalapathi9845671@gmail.com','Bangalore3'),
 (9,'Chalapathi','7795798957','chalapathi9845671@gmail.com','Bangalore'),
 (10,'Chalapathi1','7795798957','chalapathi9845672@gmail.com','Bangalore1'),
 (11,'Chalapathi2','7795798957','chalapathi9845673@gmail.com','Bangalore2'),
 (12,'Chalapathi3','7795798957','chalapathi9845671@gmail.com','Bangalore3'),
 (13,'Chalapathi','7795798957','chalapathi984567@gmail.com','Bangalore'),
 (14,'PRASANJEET KUMAR DUTTA','9620021521','jeetcse22@gmail.com','Bangalore'),
 (15,'SAGAR B.MANGASULI','9632285617','sagar.bkcc13@gmail.com','Bangalore'),
 (16,'DURGA VEERA GANESH ','9676272747','ganesh.veera1234@gmail.com','Bangalore'),
 (17,'Rajsekhar Kothari','9163104702','rajakothari16@gmail.com','Bangalore'),
 (18,'APPARAO NEKKALA','9581443328','nekkala.appaji@gmail.com','Hyderabad'),
 (19,'N.MOHAN RAJ','9865332887','nmohanraj6@gmail.com','Bangalore'),
 (20,'U.NAGAMANI','9542436746','umanivrjpt.482@gmail.com','Bangalore'),
 (21,'AMRUTHA PINNU','9177947723','amrup94@gmail.com','Bangalore'),
 (22,'B.RAMA KRISHNA','7569041390','bollimuntharamakrishna@gmail.com','Hyderabad'),
 (23,'HARSHAVARDHAN.M','8187870890','harshavardhan.1443@gmail.com','Bangalore'),
 (24,'VENKATA RAKESH.B','9901439672','bvrakesh511@gmail.com','Bangalore'),
 (25,'Chalapathi','7795798957','chalapathi984567@gmail.com','Bangalore'),
 (26,'PRASANJEET KUMAR DUTTA','9620021521','jeetcse22@gmail.com','Bangalore'),
 (27,'SAGAR B.MANGASULI','9632285617','sagar.bkcc13@gmail.com','Bangalore'),
 (28,'DURGA VEERA GANESH ','9676272747','ganesh.veera1234@gmail.com','Bangalore'),
 (29,'Rajsekhar Kothari','9163104702','rajakothari16@gmail.com','Bangalore'),
 (30,'APPARAO NEKKALA','9581443328','nekkala.appaji@gmail.com','Hyderabad'),
 (31,'N.MOHAN RAJ','9865332887','nmohanraj6@gmail.com','Bangalore'),
 (32,'U.NAGAMANI','9542436746','umanivrjpt.482@gmail.com','Bangalore'),
 (33,'AMRUTHA PINNU','9177947723','amrup94@gmail.com','Bangalore'),
 (34,'B.RAMA KRISHNA','7569041390','bollimuntharamakrishna@gmail.com','Hyderabad'),
 (35,'HARSHAVARDHAN.M','8187870890','harshavardhan.1443@gmail.com','Bangalore'),
 (36,'VENKATA RAKESH.B','9901439672','bvrakesh511@gmail.com','Bangalore');
/*!40000 ALTER TABLE `candidatedetails` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
