package com.tclabs.trainee.dao;

import com.tclabs.trainee.model.TraineeQualificationEntity;




public interface TraineeQualificationDao {
	
public boolean saveTrainee(TraineeQualificationEntity traineeQualificationEntity);
}
