package com.tclabs.trainee.service;
import com.tclabs.trainee.dto.TraineeQualificationDto;

public interface ITraineeQualificationService {
public boolean saveTraineeQly(TraineeQualificationDto traineeQualificationDto);
}
