package com.tclabs.trainee.dao;

import com.tclabs.trainee.model.TraineeEntity;

public interface ITraineeDao {
public TraineeEntity register(TraineeEntity traineeEntity);
}
