-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema candidate
--

CREATE DATABASE IF NOT EXISTS candidate;
USE candidate;

--
-- Definition of table `college`
--

DROP TABLE IF EXISTS `college`;
CREATE TABLE `college` (
  `collegeid` int(11) NOT NULL,
  `collegeName` varchar(255) default NULL,
  PRIMARY KEY  (`collegeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college`
--

/*!40000 ALTER TABLE `college` DISABLE KEYS */;
INSERT INTO `college` (`collegeid`,`collegeName`) VALUES 
 (1,'Sri Prakash College Of Engineering'),
 (2,'Avanthi College Of Engineering'),
 (3,'Pragathi Engineering College'),
 (4,'Sri Krishna Degree College'),
 (5,'Gayathri Engineering Colege');
/*!40000 ALTER TABLE `college` ENABLE KEYS */;


--
-- Definition of table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `studentid` int(11) NOT NULL,
  `collegeid` varchar(255) default NULL,
  `studentname` varchar(255) default NULL,
  PRIMARY KEY  (`studentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`studentid`,`collegeid`,`studentname`) VALUES 
 (321,'3','Akshay'),
 (322,'3','Pranav'),
 (323,NULL,NULL),
 (324,'5','Narasimha'),
 (325,'5','Avinash'),
 (421,'2','Ankith'),
 (453,'2','Mahesh'),
 (511,'1','Anusha'),
 (512,'1','Chandini'),
 (521,'2','Narayana'),
 (540,'1','Sathya'),
 (541,'1','Manikanta Pinapathruni'),
 (546,'1','Suresh'),
 (547,'1','ManikantaReddy'),
 (549,'1','Sathya'),
 (677,'4','Vinodh'),
 (678,'4','Akash');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;


--
-- Definition of table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
CREATE TABLE `student_details` (
  `ROLL_NUMBER` bigint(20) NOT NULL auto_increment,
  `AGE` int(11) default NULL,
  `FAV_SUBJECT` varchar(255) default NULL,
  `NAME` varchar(255) default NULL,
  `STANDARD` varchar(255) default NULL,
  `VILLAGE` varchar(255) default NULL,
  PRIMARY KEY  (`ROLL_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_details`
--

/*!40000 ALTER TABLE `student_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_details` ENABLE KEYS */;


--
-- Definition of table `trainee_address`
--

DROP TABLE IF EXISTS `trainee_address`;
CREATE TABLE `trainee_address` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PERMINENT_ADDRESS` varchar(255) default NULL,
  `CURRENT_ADDRESS` varchar(255) default NULL,
  `PINCODE` bigint(20) default NULL,
  `TRAINEE_ID` bigint(20) default NULL,
  PRIMARY KEY  (`ID`),
  KEY `FK34D4EF1D6D8136E6` (`TRAINEE_ID`),
  CONSTRAINT `FK34D4EF1D6D8136E6` FOREIGN KEY (`TRAINEE_ID`) REFERENCES `trainee_contact_info` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trainee_address`
--

/*!40000 ALTER TABLE `trainee_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `trainee_address` ENABLE KEYS */;


--
-- Definition of table `trainee_contact_info`
--

DROP TABLE IF EXISTS `trainee_contact_info`;
CREATE TABLE `trainee_contact_info` (
  `ID` bigint(20) NOT NULL auto_increment,
  `BIRTH_DATE` varchar(255) default NULL,
  `CONTACT_NUMBER` bigint(20) default NULL,
  `FULL_NAME` varchar(255) default NULL,
  `GENDER` varchar(255) default NULL,
  `MOBILE_NUMBER` bigint(20) default NULL,
  PRIMARY KEY  (`ID`),
  UNIQUE KEY `CONTACT_NUMBER` (`CONTACT_NUMBER`),
  UNIQUE KEY `MOBILE_NUMBER` (`MOBILE_NUMBER`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trainee_contact_info`
--

/*!40000 ALTER TABLE `trainee_contact_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `trainee_contact_info` ENABLE KEYS */;


--
-- Definition of table `trainee_qualification`
--

DROP TABLE IF EXISTS `trainee_qualification`;
CREATE TABLE `trainee_qualification` (
  `ID` bigint(20) NOT NULL auto_increment,
  `PERCENTAGE` float default NULL,
  `QUALIFICATION` varchar(255) default NULL,
  `UNIVERSITY` varchar(255) default NULL,
  `YEAR_OF_PASS` varchar(255) default NULL,
  `TRAINEE_ID` bigint(20) default NULL,
  PRIMARY KEY  (`ID`),
  KEY `FK978422586D8136E6` (`TRAINEE_ID`),
  CONSTRAINT `FK978422586D8136E6` FOREIGN KEY (`TRAINEE_ID`) REFERENCES `trainee_contact_info` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trainee_qualification`
--

/*!40000 ALTER TABLE `trainee_qualification` DISABLE KEYS */;
/*!40000 ALTER TABLE `trainee_qualification` ENABLE KEYS */;


--
-- Definition of table `useraddress`
--

DROP TABLE IF EXISTS `useraddress`;
CREATE TABLE `useraddress` (
  `id` int(11) NOT NULL auto_increment,
  `country` varchar(255) default NULL,
  `district` varchar(255) default NULL,
  `doorNo` varchar(255) default NULL,
  `mandal` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `street` varchar(255) default NULL,
  `village` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `useraddress`
--

/*!40000 ALTER TABLE `useraddress` DISABLE KEYS */;
/*!40000 ALTER TABLE `useraddress` ENABLE KEYS */;


--
-- Definition of table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
CREATE TABLE `userdetails` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(255) default NULL,
  `firstName` varchar(255) default NULL,
  `lastName` varchar(255) default NULL,
  `salary` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
