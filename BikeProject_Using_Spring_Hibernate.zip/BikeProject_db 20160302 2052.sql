-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema bankapp
--

CREATE DATABASE IF NOT EXISTS bankapp;
USE bankapp;

--
-- Definition of table `user_account_tbl`
--

DROP TABLE IF EXISTS `user_account_tbl`;
CREATE TABLE `user_account_tbl` (
  `acc_number` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `cty` varchar(45) NOT NULL,
  `phon` varchar(45) NOT NULL,
  `emai` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY  (`acc_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2342 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_account_tbl`
--

/*!40000 ALTER TABLE `user_account_tbl` DISABLE KEYS */;
INSERT INTO `user_account_tbl` (`acc_number`,`name`,`cty`,`phon`,`emai`,`password`) VALUES 
 (234,'Suresh','delhi','1234567890','sd@gmail.com','suresh'),
 (2341,'Suresh','delhi','','','');
/*!40000 ALTER TABLE `user_account_tbl` ENABLE KEYS */;


--
-- Definition of table `user_deposit_tbl`
--

DROP TABLE IF EXISTS `user_deposit_tbl`;
CREATE TABLE `user_deposit_tbl` (
  `acc_number` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(45) NOT NULL,
  `acc_type` varchar(45) NOT NULL,
  `dep_amount` varchar(45) NOT NULL,
  PRIMARY KEY  (`acc_number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_deposit_tbl`
--

/*!40000 ALTER TABLE `user_deposit_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_deposit_tbl` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
